
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.floraltonicsandtinctures.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.enchantment.Enchantment;

import net.mcreator.floraltonicsandtinctures.enchantment.FloralGiftEnchantment;
import net.mcreator.floraltonicsandtinctures.enchantment.AlchemizedEnchantment;
import net.mcreator.floraltonicsandtinctures.FloralTonicsAndTincturesMod;

public class FloralTonicsAndTincturesModEnchantments {
	public static final DeferredRegister<Enchantment> REGISTRY = DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, FloralTonicsAndTincturesMod.MODID);
	public static final RegistryObject<Enchantment> FLORAL_GIFT = REGISTRY.register("floral_gift", () -> new FloralGiftEnchantment());
	public static final RegistryObject<Enchantment> ALCHEMIZED = REGISTRY.register("alchemized", () -> new AlchemizedEnchantment());
}
