
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.floraltonicsandtinctures.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.extensions.IForgeMenuType;

import net.minecraft.world.inventory.MenuType;

import net.mcreator.floraltonicsandtinctures.world.inventory.HerbalismTableGUIMenu;
import net.mcreator.floraltonicsandtinctures.world.inventory.HerbalismKitGUIMenu;
import net.mcreator.floraltonicsandtinctures.FloralTonicsAndTincturesMod;

public class FloralTonicsAndTincturesModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.MENU_TYPES, FloralTonicsAndTincturesMod.MODID);
	public static final RegistryObject<MenuType<HerbalismTableGUIMenu>> HERBALISM_TABLE_GUI = REGISTRY.register("herbalism_table_gui", () -> IForgeMenuType.create(HerbalismTableGUIMenu::new));
	public static final RegistryObject<MenuType<HerbalismKitGUIMenu>> HERBALISM_KIT_GUI = REGISTRY.register("herbalism_kit_gui", () -> IForgeMenuType.create(HerbalismKitGUIMenu::new));
}
