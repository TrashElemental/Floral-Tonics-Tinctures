
package net.mcreator.floraltonicsandtinctures.potion;

import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

public class PricklyMobEffect extends MobEffect {
	public PricklyMobEffect() {
		super(MobEffectCategory.BENEFICIAL, -9531131);
	}

	@Override
	public boolean isDurationEffectTick(int duration, int amplifier) {
		return true;
	}
}
