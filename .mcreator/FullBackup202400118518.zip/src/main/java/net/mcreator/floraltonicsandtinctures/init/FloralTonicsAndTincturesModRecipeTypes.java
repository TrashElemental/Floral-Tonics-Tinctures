package net.mcreator.floraltonicsandtinctures.init;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.event.lifecycle.FMLConstructModEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.IEventBus;

import net.minecraft.world.item.crafting.RecipeSerializer;

import net.mcreator.floraltonicsandtinctures.jei_recipes.JEIHerbalismRecipeTypeRecipe;
import net.mcreator.floraltonicsandtinctures.FloralTonicsAndTincturesMod;

@Mod.EventBusSubscriber(modid = FloralTonicsAndTincturesMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class FloralTonicsAndTincturesModRecipeTypes {
	public static final DeferredRegister<RecipeSerializer<?>> SERIALIZERS = DeferredRegister.create(ForgeRegistries.RECIPE_SERIALIZERS, "floral_tonics_and_tinctures");

	@SubscribeEvent
	public static void register(FMLConstructModEvent event) {
		IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
		event.enqueueWork(() -> {
			SERIALIZERS.register(bus);
			SERIALIZERS.register("jei_herbalism_recipe_type", () -> JEIHerbalismRecipeTypeRecipe.Serializer.INSTANCE);
		});
	}
}
