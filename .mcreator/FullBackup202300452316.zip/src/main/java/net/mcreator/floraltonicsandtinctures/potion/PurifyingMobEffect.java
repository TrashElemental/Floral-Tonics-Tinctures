
package net.mcreator.floraltonicsandtinctures.potion;

import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

public class PurifyingMobEffect extends MobEffect {
	public PurifyingMobEffect() {
		super(MobEffectCategory.BENEFICIAL, -1910811);
	}

	@Override
	public String getDescriptionId() {
		return "effect.floral_tonics_and_tinctures.purifying";
	}

	@Override
	public boolean isDurationEffectTick(int duration, int amplifier) {
		return true;
	}
}
